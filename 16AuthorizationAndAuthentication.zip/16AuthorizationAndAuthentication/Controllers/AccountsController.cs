﻿using _16AuthorizationAndAuthentication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _16AuthorizationAndAuthentication.Controllers
{
    public class AccountsController : Controller
    {
        // GET: Accounts
        CollegeDbContext db = new CollegeDbContext();

        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(AppUser appUser)
        {
            if (ModelState.IsValid)
            {
                db.AppUsers.Add(appUser);
                db.SaveChanges();
                return RedirectToAction("Login", "Accounts");
            }
            return View(appUser);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel loginViewModel)
        {
            return View();
        }

        public ActionResult SignOut()
        {
            return View();
        }
    }
}